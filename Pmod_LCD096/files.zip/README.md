# LCD Test Pattern – Tang Primer 25K

## 概要
ST7735S搭載 Pmod-LCD-0.96 に **7色縦じまテストパターン** を表示する  
FPGA デザイン（Verilog / GOWIN EDA）です。

## ファイル構成

```
lcd_test/
├── src/
│   ├── top.v              ← トップレベル（クロック分周・テストパターン生成）
│   └── lcd_controller.v   ← ST7735S 初期化 + SPI 送信ステートマシン
├── sim/
│   └── tb_top.v           ← シミュレーション用テストベンチ
├── lcd_test.cst           ← ピン制約（GOWIN Physical Constraints）
├── lcd_test.sdc           ← タイミング制約
└── README.md
```

## ハードウェア構成

| 信号     | Tang Primer 25K ピン | Pmod ピン |
|----------|---------------------|-----------|
| lcd_cs   | A11                 | Pmod1     |
| lcd_mosi | E11                 | Pmod2     |
| lcd_dc   | K11                 | Pmod3     |
| lcd_clk  | L5                  | Pmod4     |
| lcd_rst  | K5                  | Pmod8     |
| clk      | H11                 | オンボード 27 MHz |
| rst_n    | T10                 | S1 ボタン |

## テストパターン（RGB565）

| 縦じま | 色      | RGB565 |
|--------|---------|--------|
| 1      | 赤      | 0xF800 |
| 2      | 緑      | 0x07E0 |
| 3      | 青      | 0x001F |
| 4      | シアン  | 0x07FF |
| 5      | マゼンタ| 0xF81F |
| 6      | 黄      | 0xFFE0 |
| 7      | 白      | 0xFFFF |

各ストライプ幅：約18〜19ピクセル（132px / 7色）

## GOWIN EDA プロジェクト作成手順

1. GOWIN EDA を起動し、**New Project** を選択
2. デバイス選択：`GW5A-LV25MG121NES`（Tang Primer 25K）
3. ソースファイルを追加：
   - `src/top.v`
   - `src/lcd_controller.v`
4. 制約ファイルを追加：
   - `lcd_test.cst`（Physical Constraints）
   - `lcd_test.sdc`（Timing Constraints）
5. **Synthesize** → **Place & Route** → **Generate Bitstream**
6. **Program Device** で FPGA に書き込み

## 設計メモ

### SPI クロック
- システムクロック 27 MHz を 2 分周 → **13.5 MHz** SPI クロック
- ST7735S の最大 SPI クロックは 15.15 MHz（仕様書より）

### 初期化シーケンス
1. ハードウェアリセット（RST Lo → 15ms → Hi → 150ms wait）
2. SWRESET（0x01）→ 150ms wait
3. SLPOUT（0x11）→ 150ms wait
4. COLMOD（0x3A）= 0x05：16ビット RGB565
5. MADCTL（0x36）= 0x00：通常向き
6. 電源・ガンマ設定
7. CASET / RASET（列・行アドレス設定）
8. DISPON（0x29）
9. RAMWR（0x2C）→ 全画素（132×162 = 21384ピクセル）書き込み
10. フレーム完了後ループ

### ステートマシン
```
RESET_LO → RESET_HI → SEND_BYTE (ROM1) → DELAY (SWRESET)
         → SEND_BYTE (ROM1 続き) → DELAY (SLPOUT)
         → SEND_BYTE (ROM2) → SEND_BYTE (ROM3)
         → PIXEL_REQ → PIXEL_TX → PIXEL_NXT → (ループ)
```

## シミュレーション（iverilog）

```bash
iverilog -o sim.out sim/tb_top.v src/top.v src/lcd_controller.v
vvp sim.out
gtkwave tb_top.vcd
```
