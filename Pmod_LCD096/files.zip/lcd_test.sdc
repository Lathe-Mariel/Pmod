//Copyright (C)2014-2024 Gowin Semiconductor Corporation.
//SDC Constraints for lcd_test

// 27 MHz system clock
create_clock -name clk -period 37.037 [get_ports {clk}]

// SPI clock derived from clk (clk_div)
create_generated_clock -name spi_clk \
    -source [get_ports {clk}] \
    -divide_by 2 \
    [get_nets {spi_clk}]

// Relax output timing (LCD SPI is not high-speed)
set_output_delay -clock clk -max  5.0 [get_ports {lcd_cs lcd_mosi lcd_dc lcd_clk lcd_rst}]
set_output_delay -clock clk -min -5.0 [get_ports {lcd_cs lcd_mosi lcd_dc lcd_clk lcd_rst}]
