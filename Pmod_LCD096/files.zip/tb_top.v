// ============================================================
// tb_top.v  –  Simple simulation testbench
// ============================================================
`timescale 1ns/1ps

module tb_top;

reg  clk;
reg  rst_n;

wire lcd_cs, lcd_mosi, lcd_dc, lcd_clk, lcd_rst;

// 27 MHz clock
initial clk = 0;
always #18.518 clk = ~clk;   // ~27 MHz

// DUT
top dut (
    .clk      (clk),
    .rst_n    (rst_n),
    .lcd_cs   (lcd_cs),
    .lcd_mosi (lcd_mosi),
    .lcd_dc   (lcd_dc),
    .lcd_clk  (lcd_clk),
    .lcd_rst  (lcd_rst)
);

// Capture SPI transactions
integer byte_count;
reg [7:0] shift_reg;
reg [3:0] bit_cnt;
reg       prev_cs;

initial begin
    byte_count = 0;
    bit_cnt    = 0;
    shift_reg  = 0;
    prev_cs    = 1;
end

always @(posedge lcd_clk) begin
    if (!lcd_cs) begin
        shift_reg = {shift_reg[6:0], lcd_mosi};
        bit_cnt   = bit_cnt + 1;
        if (bit_cnt == 4'd8) begin
            $display("[%0t ns] %s 0x%02X",
                $time,
                lcd_dc ? "DAT" : "CMD",
                shift_reg);
            bit_cnt    = 0;
            byte_count = byte_count + 1;
        end
    end
end

// Stimulus
initial begin
    rst_n = 0;
    #200;
    rst_n = 1;
    // Run long enough to see init sequence (fast sim)
    // Real timing would require much longer run
    #5_000_000;
    $display("Simulation done. SPI bytes seen: %0d", byte_count);
    $finish;
end

// VCD dump
initial begin
    $dumpfile("tb_top.vcd");
    $dumpvars(0, tb_top);
end

endmodule
